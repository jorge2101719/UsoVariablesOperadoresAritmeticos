// Operaciones con dos valores
alert('Inicialmente haremos algunas operaciones básicas con un par de guarismos');
var num1 = +prompt("Ingrese el primer número");
var num2 = +prompt("Ingrese el segundo número");

document.write(`Los números ingresados fueron el ${num1} y ${num2} <br>`);

document.write(`La suma es: ${num1 + num2} <br>`);
document.write(`La resta es: ${num1 - num2} <br>`);
document.write(`La multiplicación es: ${num1 * num2} <br>`);
document.write(`La división es ${num1 / num2} <br>`);
document.write(`El módulo es ${num1 % num2} <br> <br>`);

// Transformación de temperatura
alert('Procederemos a transformar la temperatura');
var temperatura = +prompt("Ingrese la temperatura");
document.write(`La temperatura ingresada (en Celcius) fue: ${temperatura} <br>`);
document.write(`${temperatura} grados Celcius equivalen a ${temperatura + 273.15} Kelvin y ${(temperatura + 9 / 5) + 32} Fahrenheit <br> <br>`);


// Transformación de los días
alert('Transformaremos el valor de días dados en años, meses, semanas, días')
var dias = +prompt("Ingrese el número de días");
document.write('El año está idealizado en 365 días y el mes en 30, por lo se dan algunos resultados inesperados <br>');
document.write(`Usted ha ingresado ${dias} día(s) <br>`);

var a = (dias / 365) //- Math.floor(dias / 365);
document.write(`${dias} día(s) equivalen a: ${Math.floor(a)} año(s) <br>`);

dias = (a - Math.floor(a)) * 365;

var meses = (dias / 30);
document.write(`${Math.floor(meses)} mes(es) <br>`);

dias = (meses - Math.floor(meses)) * 30;

var semanas = (dias / 7);
document.write(`${Math.floor(semanas)} semana(s) <br>`);

dias = (semanas - Math.floor(semanas)) * 7;

document.write(`${Math.round(dias)} día(s) `)


document.write(`<br> <br>`);

// Suma y promedio de cinco números
alert("Ahora usted debe ingresar cinco números");
var numero1 = +prompt('ingrese el primer número');
var numero2 = +prompt('ingrese el segundo número');
var numero3 = +prompt('ingrese el tercer número');
var numero4 = +prompt('ingrese el cuarto número');
var numero5 = +prompt('ingrese el quinto número');

var suma = numero1 + numero2 + numero3 + numero4 + numero5;
document.write(`Usted ha ingresado los números ${numero1}, ${numero2}, ${numero3}, ${numero4} y ${numero5} <br>`);
document.write(`La suma de los cinco valores ingresados es: ${suma} y su promedio es ${suma/5}`);

//const pi = 3.1415926536;
//var num = prompt('Ingrese número para multiplicar por "pi": ');
//alert(pi * num);





